package com.jwhh.androidbooks;

import android.view.View;

/**
 * Created by Jim on 11/24/2015.
 */
public interface OnSelectedBookChangeListener {
    void onSelectedBookChanged(View view, int bookIndex);
}

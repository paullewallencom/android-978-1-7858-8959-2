package com.jwhh.androidbooks;

/**
 * Created by Jim on 2/5/2016.
 */
public interface OnSelectedBookChangeListener {
    void onSelectedBookChanged(int bookIndex);
}
